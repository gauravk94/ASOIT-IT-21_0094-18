<!DOCTYPE html>
<html>
<body>

<?php
echo strpos("Hello world!", "world");
?> 

<?php
$x = 1.9e411;
var_dump($x);
?>  

<?php
$x = acos(8);
var_dump($x);
?>  

<?php
$x = 5985;
var_dump(is_numeric($x));

echo "<br>";

$x = "5985";
var_dump(is_numeric($x));

echo "<br>";

$x = "59.85" + 100;
var_dump(is_numeric($x));

echo "<br>";

$x = "Hello";
var_dump(is_numeric($x));
?>  

</body>
</html>
